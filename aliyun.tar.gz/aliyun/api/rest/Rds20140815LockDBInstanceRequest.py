'''
Created by auto_sdk on 2015.05.28
'''
from aliyun.api.base import RestApi
class Rds20140815LockDBInstanceRequest(RestApi):
	def __init__(self,domain='rds.aliyuncs.com',port=80):
		RestApi.__init__(self,domain, port)
		self.DBInstanceId = None
		self.LockReason = None
		self.ownerId = None
		self.resourceOwnerAccount = None
		self.resourceOwnerId = None

	def getapiname(self):
		return 'rds.aliyuncs.com.LockDBInstance.2014-08-15'
