'''
Created by auto_sdk on 2014.08.07
'''
from aliyun.api.base import RestApi
class Ecs20140526DescribeInstanceStatusRequest(RestApi):
	def __init__(self,domain='ecs.aliyuncs.com',port=80):
		RestApi.__init__(self,domain, port)
		self.ClusterId = None
		self.PageNumber = None
		self.PageSize = None
		self.RegionId = None
		self.ZoneId = None

	def getapiname(self):
		return 'ecs.aliyuncs.com.DescribeInstanceStatus.2014-05-26'
