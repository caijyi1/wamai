'''
Created by auto_sdk on 2015.04.16
'''
from aliyun.api.base import RestApi
class Ecs20140526DeleteSecurityGroupRequest(RestApi):
	def __init__(self,domain='ecs.aliyuncs.com',port=80):
		RestApi.__init__(self,domain, port)
		self.RegionId = None
		self.SecurityGroupId = None

	def getapiname(self):
		return 'ecs.aliyuncs.com.DeleteSecurityGroup.2014-05-26'
