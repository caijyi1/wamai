# -*- coding: utf-8 -*-
from aliyun.api.rest import *
from aliyun.api.base import FileItem